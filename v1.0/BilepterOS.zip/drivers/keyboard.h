#include "../cpu/type.h"

void init_keyboard();
